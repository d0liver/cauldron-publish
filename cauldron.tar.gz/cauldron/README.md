To extract:
``
rm -rf ./cauldron && \
	mkdir cauldron && \
	tar -C cauldron -xzvf ~/mono/public/cauldron.tar.gz \
	--strip-components 2

chmod u+x ./cauldron/bin/cauldron
cd ./cauldron
npm install
``

Then add `bin/` to your `$PATH`.

To make the archive:

``
local tmpDir="$(mktemp -d)"

cd ~/cauldron

mkdir -p "$tmpDir/cauldron/bin"
cp package.json "$tmpDir/cauldron"

spago bundle \
	--platform node \
	--outfile "$tmpDir/cauldron/bin/cauldron" \
	--bundle-type app \
	--module Main \
	--bundler-args '--external:better-sqlite3'

# mkdir -p ~/mono/public/cauldron/bin
# cp package.json ~/mono/public/cauldron
# mv "$tmp" ~/mono/public/cauldron/bin/cauldron
tar -C "$tmpDir" -cvzf - . > ~/mono/public/cauldron.tar.gz
``

## Suggested aliases
``
# Usage: cf <tag1> <tag2>
# Gets results for the supplied tags and then filters them down with fuzzy
# finder and saves them as the current selections. Subsequent commands given
# without params will use the saved selection set.
cf () {
  local tags="$@"

  caul ls "$tags" > /dev/null && \
    caul narrow $(caul ls | fzf -m | awk '{print $1}')
}
``
